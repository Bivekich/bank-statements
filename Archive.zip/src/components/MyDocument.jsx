import React from "react";
import { Page, Text, Document, StyleSheet } from "@react-pdf/renderer";

const styles = StyleSheet.create({
  page: {
    padding: 20,
  },
  text: {
    fontSize: 12,
    marginBottom: 5,
  },
  h2: {
    color: "rgb(229, 20, 60)",
    fontSize: 64,
    fontWeight: "normal",
    fontStyle: "normal",
  },
});

const SimpleDocument = ({ bank, userType, formData, transactions }) => (
  <Document>
    <Page style={styles.page}>
      <Text style={styles.text}>info: {bank}</Text>
      <Text style={styles.text}>info: {userType}</Text>
      <Text style={styles.text}>info: {formData.name}</Text>
      <Text style={styles.text}>info: {formData.address}</Text>
      <Text style={styles.text}>info: {formData.accountNumber}</Text>
      <Text style={styles.text}>info: {formData.routingNumber}</Text>
      <Text style={styles.text}>info: {formData.balanceStart}</Text>
      <Text style={styles.text}>info: {formData.balanceEnd}</Text>
      <Text style={styles.text}>info: {formData.period}</Text>

      <Text style={styles.text}>transactions:</Text>
      {transactions.map((transaction, index) => (
        <Text key={index} style={styles.text}>
          Date: {transaction.date}, Name: {transaction.description}, Type:{" "}
          {transaction.type}, Symm: {transaction.amount}, Balance:{" "}
          {transaction.balance}
        </Text>
      ))}
    </Page>
    <Page style={styles.page}>
      <Text style={styles.h2}>IMPORTANT INFORMATION:</Text>
    </Page>
  </Document>
);
// const SimpleDocument = ({ bank, userType, formData, transactions }) => (
//   <Document>
//     <Page style={styles.page}>
//       <Text style={styles.text}>info: {bank}</Text>
//       <Text style={styles.text}>info: {userType}</Text>
//       <Text style={styles.text}>info: {formData.name}</Text>
//       <Text style={styles.text}>info: {formData.address}</Text>
//       <Text style={styles.text}>info: {formData.accountNumber}</Text>
//       <Text style={styles.text}>info: {formData.routingNumber}</Text>
//       <Text style={styles.text}>info: {formData.balanceStart}</Text>
//       <Text style={styles.text}>info: {formData.balanceEnd}</Text>
//       <Text style={styles.text}>info: {formData.period}</Text>

//       <Text style={styles.text}>transactions:</Text>
//       {transactions.map((transaction, index) => (
//         <Text key={index} style={styles.text}>
//           Date: {transaction.date}, Name: {transaction.description}, Type:{" "}
//           {transaction.type}, Symm: {transaction.amount}, Balance:{" "}
//           {transaction.balance}
//         </Text>
//       ))}
//     </Page>
//     <Page style={styles.emptyPage}></Page>
//   </Document>
// );

export default SimpleDocument;
